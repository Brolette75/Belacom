var mongoose = require('mongoose');

async function connect() {
    try {
        await mongoose.connect("mongodb://localhost:27017/belacom", {useNewUrlParser: true})
        .then((ans) => {
            console.log("Connected Successful");
        })
        .catch((err) => {
            console.log("Error in the Connection");
        });
    } catch (error) {
        console.error(error);
    }
}

module.exports = connect;