const { response } = require('express');
const Utilisateur = require('./../models/utilisateur')

exports.createUtilisateur = async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    const user = await Utilisateur.findOne({ email: req.body.email });
    if (user) {
        res.status(407).json({ url: req.url, message: "User already exist" })
    }
    else {
        try {
            const utilisateur = new Utilisateur(req.body);
            const result = await utilisateur.save();

            if (result) {
                res.status(200).send();
            } else {
                res.status(401).send({ error: 'Error: bad body' });
            }
        } catch (e) {
            res.status(522).send({ error: 'Something were wrong' });
        }
    }
};
