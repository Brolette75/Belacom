require('dotenv').config()
const express = require('express');
const router = express.Router();
const utilisateurController = require('../controller/utilisateur');

router.post('/', utilisateurController.createUtilisateur);

module.exports = router;
