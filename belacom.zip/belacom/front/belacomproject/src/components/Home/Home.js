import React from 'react';
import axios from 'axios';
import './home.css'

const handleSubmit = (e) => {
    e.preventDefault();

    const name = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;

    axios.post('http://localhost:8080/api/utilisateur/', { "name": name, "email": email, "password": password }).then((res) => {
    });

}

const Home = () => {
    return (
        <div className='container-belacom'>
            <section className='designbackgroundform'>
                <h3>Enregistrez-vous:</h3>
                <form onSubmit={handleSubmit} class="form-example">
                    <label for="name">Enter your name: </label>
                    <input type="text" name="name" id="name" required></input>
                    <label for="email">Enter your email: </label>
                    <input type="email" name="enteredmail" id="mail" required></input>
                    <label for="email">Enter your password: </label>
                    <input type="password" name="enteredpassword" id="passwd" required></input>
                    <input id='connect' type="submit" value="Subscribe"></input>
                </form>
            </section>
            <div className='img-container'>
                <img src='images/giraffe.png'></img>
            </div>
        </div>
    );
};

export default Home;