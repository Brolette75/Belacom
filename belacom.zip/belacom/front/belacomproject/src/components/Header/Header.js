import React from 'react';
import './header.css'

const Header = () => {
    return (
        <>
        <header>
            <div className='header-block'>
                <img src="images/Belacom_Logo.svg" alt="Logo Belacom"/>    
            </div>
        </header>
        </>
    );
};

export default Header;